function ControlarSelecao(){
  var resposta = document.getElementById("resposta");
  var numero1 = parseFloat (document.getElementById ("numero1").value);
  var numero2 = parseFloat (document.getElementById ("numero2").value);
  var resposta = parseFloat (document.getElementById ("resposta").value);
  var txt='';

  if(document.getElementById ('add').checked );
  txt = add (numero1 + numero2);

  if(document.getElementById ('subtract').checked );
  txt = subtract (numero1 - numero2);

  if(document.getElementById ('divide').checked );
  txt = divide (numero1 / numero2);

  if(document.getElementById ('multiply').checked );
  txt = multiply (numero1 * numero2);
 
  if(document.getElementById ('calcular').checked );
  txt = calcular (resposta);

  
  resposta.innerHTML = txt;
}
function add (numero1,numero2){
    return (numero1+numero2);
}
function subtract (numero1,numero2){
    return (numero1-numero2);
}
function divide(numero1,numero2){
    return (numero1/numero2);
}
function multiply(numero1,numero2){
    return (numero1*numero2);
}
function mostrarResultado(numero1,numero2){
    "numero1"=document.getElementById('numero1').value
    "numero2"=document.getElementById('numero2').value
    console.log(resposta)
}